<?php
	$data = $_POST['data'];
	if (!empty($data)) {
		$connect1 = mysqli_connect('dev-friox.com:3310', 'esm211', '000211');
		$db = mysqli_select_db($connect1, 'miss');
		if ($db) {
			$sql = "INSERT INTO user_info VALUES(1, '";
			$sql = $sql.$data[0]."', password('";
			$sql = $sql.$data[2]."'), '";
			$sql = $sql.$data[1]."')";
			$result = mysqli_query($connect1, $sql);
			if ($result) {
				echo "<script>alert('데이터 삽입 성공 하였습니다.');</script>";
			} else {
				echo "<script>alert('데이터 삽입 실패 하였습니다.');</script>";
			}
		} else {
			echo "<script>alert('연결 실패 하였습니다.');</script>";
		}
	}
?>

<html>
	<head>
		<title> FROM 태그를 이용하여 - 회원등록 </title>
	</head>

	<body>
		<br><h2><center>  회원 등록  </center></h2><hr>

	<form method="post" action="input_record.php">
		<center>
		<table border=0 bordercolor="blue" width=700 cellspacing=1 cellpadding=5>
			<colgroup>
				<col style="width: 150px"></col>
				<col style="width: 200px"></col>
				<col style="width: 150px"></col>
				<col style="width: 200px"></col>
			</colgroup>

			<tr>
				<td align=right> ID : </td>
				<td>
					<input type="text" maxlength=10 name="data[]">
				</td> 

				<td align=right> NickName : </td>
				<td>
					<input type="text" maxlength=10 name="data[]">
				</td>
			</tr>

			<tr>
				<td align=right> Pass : </td>
				<td>
					<input type="password" maxlength=10 name="data[]">
				</td>

				<td align=right> Pass_check : </td>
				<td>
					<input type="password" maxlength=10 name="data[]">
				</td>
			</tr>
	
		</table><br>

		<table border=0 width=800>
			<tr>
				<td align=center>
					<input type="submit" value=" ◀ 회원 등록 ▶ "> &nbsp;&nbsp;&nbsp;&nbsp;
					<input type ="reset" value=" ▶ 다시 작성 ◀ ">
				</td>
			</tr>
		</table>
		<center>
		<input type="hidden" name="thema" value="회원 등록 서식">
		</center>
	</form>
	</body>
</html>